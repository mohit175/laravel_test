<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/page1/all-data', 'Page1Controller@getAllData')->name('all_data');
Route::post('/page1/save', 'Page1Controller@saveData')->name('save_data');
Route::post('/page1/edit', 'Page1Controller@editData')->name('edit_data');
Route::post('/page1/delete', 'Page1Controller@deleteData')->name('delete_data');



Route::get('/page2', 'Page2Controller@index')->name('Page2');
Route::post('/page2/save', 'Page2Controller@sataData')->name('page2_save_data');

