<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class page1 extends Model
{
    public $table = "page1";
}
