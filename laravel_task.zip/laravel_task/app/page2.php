<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class page2 extends Model
{
    public $table = "page2";
}
