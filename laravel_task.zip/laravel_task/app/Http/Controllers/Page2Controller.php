<?php

namespace App\Http\Controllers;

use App\page2;
use Illuminate\Http\Request;

class Page2Controller extends Controller
{
    public function index(){
        return view('page2');
    }

    public function sataData(){
        $category = explode(', ' , $_POST['category']);
        print_r($category);
        try{
            foreach($category as $value){
                $page1 =  new page2();
                $page1->category =  $value;
                $page1->save();
            }
            return "data save successfully" ;
        }catch(\Exception $e){
            return $e;
        }


        //return view('page2');
    }
}
