<?php

namespace App\Http\Controllers;

use App\page1;
use Illuminate\Http\Request;
use Mockery\CountValidator\Exact;

class Page1Controller extends Controller
{
    public function saveData(){
        try{
            $page1 =  new page1();
            $page1->name =  $_POST['name'];
            $page1->save();
            return "data save successfully" ;
        }catch(\Exception $e){
            return $e;
        }
    }

    public function editData(){
        try{
            $page1 =  page1::find($_POST['edit_id']);
            $page1->name =  $_POST['name'];
            $page1->save();
            return "data updated successfully" ;
        }catch(\Exception $e){
            return $e;
        }
    }

    public function deleteData(){
        $page1 =  page1::find($_POST['id']);
        $page1->delete();
    }

    public function getAllData(){
        $page1 =  new page1();
        $page1_data    = $page1->all()->toArray();
        return $page1_data;
    }
}
