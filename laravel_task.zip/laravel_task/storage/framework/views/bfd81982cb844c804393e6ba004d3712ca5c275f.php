<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    <?php echo csrf_field(); ?>
                <label>Name :- </label>
                <input type="hidden" name="edit_id" id="edit_id"><br>
                <input type="text" name="name" id="name"><br>
                <button id="submit">Submit</button>

            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div id="show_data">
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){

    getAllData();


    $("#submit").on("click",function(){
        if($("#edit_id").val() == ""){
            $.ajax({
                url:"<?php echo e(route('save_data')); ?>",
                type:"post",
                data:{"name":$("#name").val(),"_token":$("input[name=_token]").val()},
                success:function(data){
                    $("#name").val('');
                    getAllData();
                }
            });
        }else{
            $.ajax({
                url:"/laravel_task/public/page1/edit",
                type:"post",
                data:{"edit_id":$("#edit_id").val(),"name":$("#name").val(),"_token":$("input[name=_token]").val()},
                success:function(data){
                    $("#edit_id").val('');
                    $("#name").val('');
                    getAllData();
                }
            });
        }
    });
});


function edit(id,name){
    $("#name").val(name);
    $("#edit_id").val(id);
}

function delete_data(id){
    $.ajax({
            url:"<?php echo e(route('delete_data')); ?>",
            type:"post",
            data:{"id":id,"_token":$("input[name=_token]").val()},
            success:function(data){
                getAllData();
            }
    });
}



function getAllData(){
    $.ajax({
        url:"<?php echo e(route('all_data')); ?>",
        type:"get",
       // data:{"name":$("#name").val(),"_token":$("input[name=_token]").val()},
        success:function(data){
            var show_data = '<table style="font-family: arial, sans-serif;border-collapse: collapse;width: 100%;">\
                                <tr>\
                                    <th>id</th>\
                                    <th>name</th>\
                                    <th>action</th>\
                                </tr>';
            $.each(data,function(key,value){
            show_data +='  <tr>\
                                    <td>'+value.id+'</td>\
                                    <td>'+value.name+'</td>\
                                    <td><button onclick=edit('+value.id+',"'+value.name+'")>Edit</button>&nbsp;&nbsp;<button onclick=delete_data('+value.id+')>Delete</button></td>\
                                </tr>';

            });

            $('#show_data').html(show_data);


        }
    });

}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_task\resources\views/home.blade.php ENDPATH**/ ?>