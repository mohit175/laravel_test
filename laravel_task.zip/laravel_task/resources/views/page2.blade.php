@extends('layouts.app')

@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                    @csrf
                <label>category  :- </label>
                <input type="text" name="category" id="category"><br>
                <button id="add">add</button>

            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div id="show_data">
                </div>
                <button id="submit">Submit</button>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    if(sessionStorage.getItem('all_category')){
        $('#show_data').html(sessionStorage.getItem('all_category'));
    }

    if($("#show_data").text() == ''){
            $("#submit").hide();
    }

    $("#add").on("click",function(){
        $("#submit").show();
        if($("#show_data").text() == ''){
            $("#show_data").append($("#category").val());
        }else{
            $("#show_data").append(', '+$("#category").val());
        }
        $("#category").val('');
        sessionStorage.setItem('all_category', $("#show_data").text());
    });


    $("#submit").on("click",function(){

        $.ajax({
            url:"{{route('page2_save_data')}}",
            type:"post",
            data:{"category":$("#show_data").text(),"_token":$("input[name=_token]").val()},
            success:function(data){
                alert('data save successfully');
                sessionStorage.removeItem("all_category");
                $("#show_data").text('');
                $("#submit").hide();
            }
        });

    });
});



</script>
@endsection
